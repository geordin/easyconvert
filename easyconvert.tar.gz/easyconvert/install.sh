#!/bin/bash

INFO="$(echo "[`date '+%a %b %T %Y'`][INFO]")"
ERROR="$(echo "[`date "+%a %b %T %Y"`][ERROR]")"

echo "$INFO Copying the binaries"
cp -rf easyconvert /usr/local/
echo "$INFO Setting the binaries"
ln -s /usr/local/easyconvert/easyconvert /usr/local/bin/easyconvert
