#!/bin/bash

INFO="$(echo "[`date '+%a %b %T %Y'`][INFO]")"
ERROR="$(echo "[`date "+%a %b %T %Y"`][ERROR]")"

echo "$INFO Unsetting the binaries"
unlink /usr/local/bin/easyconvert
echo "$INFO Removing the binaries"
rm -rf /usr/local/easyconvert
